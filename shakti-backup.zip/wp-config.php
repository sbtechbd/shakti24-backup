<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'shakti24_database');

/** MySQL database username */
define('DB_USER', 'shakti24_panel');

/** MySQL database password */
define('DB_PASSWORD', 'Tribedi1tare@#15Shap');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'RdTk~@_0!Q%dWX-|Ub7eBaw>@Q|%r!|fFQ=#F=H)O)&;_Sa`$:VHJtc)jPJq/i$@');
define('SECURE_AUTH_KEY',  '1h`t4kG}o014zPO%oGT!-_,eY;PBQY}2gi&J3HWY=%<z&%OdAJ*4XWW)icUzv+[y');
define('LOGGED_IN_KEY',    '6[,:-6RFsAE]y2X893#DMYYfqHLbJ4Q/;;_]%AWn6EE#<uWp`=NGt0zs7Q&TFj@m');
define('NONCE_KEY',        'c}2%UqyFDcC=r/Qoi4=`4_(?q~UT2YuzD}}[]=dX{UT2`1CH04/G*Qke|i !B QT');
define('AUTH_SALT',        'Kh.mmDGU%xeCm*mnQxOJRCS{?t@Sy}vR5#Ao+;V29eK *Hwp/8h;hI0lt)9Nu:f=');
define('SECURE_AUTH_SALT', 'Z}9xRv1-Tw;P_+c0|PE|.pl[^noT<kn$<fow/%l(km?yrqnGNMe4~PHoE@6ZoCi`');
define('LOGGED_IN_SALT',   '7DW`fwe#2z|5>Yx|{ZQptW32A1JFlFLC%9X5y2VXD~QbaD`ndy)(+|1*9+4x{7Df');
define('NONCE_SALT',       'exKE(oTZ)l*a6E>md(DU4I<L w7se?+O|zc2!Y@?n4b7^ai#oD>=2!=<<:HOkUOG');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
